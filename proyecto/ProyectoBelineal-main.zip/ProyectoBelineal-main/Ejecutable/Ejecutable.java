package Ejecutable;

import Vista.VentanaPrincipal;

public class Ejecutable {
    public static void main(String[] args) {
        VentanaPrincipal miVentanaPrincipal = new VentanaPrincipal();
    }
}